#include <stdio.h>
int main() {
  printf("%s",1);
}
